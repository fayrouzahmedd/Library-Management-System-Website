
INSERT INTO [dbo].[books]([title],[author],[year])VALUES(@title, ,@author,@year)


DECLARE @title varchar(255);
DECLARE @author varchar(255);
DECLARE @year varchar(255);