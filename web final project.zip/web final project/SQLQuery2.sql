INSERT INTO books (title, author, year) VALUES ('The Great Gatsby', 'F. Scott Fitzgerald', 1925);


SELECT * FROM books;

UPDATE books SET title = 'The Great Gatsby (Revised Edition)' WHERE id = 1;

DELETE FROM books WHERE id = 1;


INSERT INTO books (title, author, year) VALUES ('lara', 'iuygfdrt', -0987654);

