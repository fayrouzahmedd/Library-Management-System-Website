select * from books

insert into books values ('haneen','haneen','1990')