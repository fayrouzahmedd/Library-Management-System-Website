CREATE TABLE Usertbl (
user_id INT PRIMARY KEY NOT NULL IDENTITY,
username VARCHAR(255) NOT NULL,
password VARCHAR(255) NOT NULL,
);

insert into Usertbl values ('admin','123')
insert into Usertbl values ('lara','123')

select * from Usertbl